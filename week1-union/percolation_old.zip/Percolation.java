import edu.princeton.cs.algs4.WeightedQuickUnionUF;
import edu.princeton.cs.algs4.StdRandom;

public class Percolation {

    private int[][] field;
    private int countOpen;
    private WeightedQuickUnionUF unionUF;
    private final int N;
    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0)
            throw new IllegalArgumentException();
        N = n;
        // игровое поле. 2 доп строки (чтобы не пересчитывать), столбцы тоже (но можно меньше)
        field = new int[n + 2][n + 2];
        countOpen = 0;
        // подсчет объединений
        unionUF = new WeightedQuickUnionUF((n + 2) * (n + 2));
        int last_idx = (n + 2) * (n + 2) - 1;
        field[0][0] = 1;
        field[N + 1][0] = 1;
        for (int i = 1; i <= N + 1; i++) {
            // принудительно объединяем первую и последнюю строки
            field[0][i] = 1;
            field[N + 1][i] = 1;
            unionUF.union(0, i);
            unionUF.union(last_idx, last_idx - i);
        }
    }

    private void validate(int row, int col) {
        if (row < 1 || row > N || col < 1 || col > N) {
            throw new IllegalArgumentException("index (" + row + ", " + col + ") is not between 1 and " + N);
        }
    }

    private void union(int rowF, int colF, int rowS, int colS) {
        int pF = rowF * (N + 2) + colF;
        int pS = rowS * (N + 2) + colS;
        unionUF.union(pF, pS);
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        validate(row, col);
        if (field[row][col] != 1) {
            field[row][col] = 1;
            countOpen++;
            int[] aRow = new int[] {row - 1, row + 1, row, row};
            int[] aCol = new int[] {col, col, col - 1, col + 1};
            for (int i = 0; i < 4; i++) {
                if (field[aRow[i]][aCol[i]] == 1)
                    union(aRow[i], aCol[i], row, col);
            }
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        validate(row, col);
        return field[row][col] == 1;
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        validate(row, col);
        int iF = unionUF.find(0);
        int iU = unionUF.find(row * (N + 2) + col);
        // int iL = unionUF.find((N + 2) * (N + 2) - 1);
        return iF == iU;  // || iU == iL;
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return countOpen;
    }

    // does the system percolate?
    public boolean percolates() {
        int iF = unionUF.find(0);
        int iL = unionUF.find((N + 2) * (N + 2) - 1);
        return iF == iL;
    }

    // test client (optional)
    public static void main(String[] args) {
        int n = 20;
        Percolation p = new Percolation(n);
        int count = 0;
        while (!p.percolates()) {
            int iR = StdRandom.uniform(1, n + 1);
            int iC = StdRandom.uniform(1, n + 1);
            if (p.isFull(iR, iC)) {
                p.open(iR, iC);
                count++;
            }
        }
//        System.out.println(p.percolates());
//        System.out.println(p);
        System.out.println(1.0 * count / n / n);
    }
}