import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;

public class FastCollinearPoints {
    // finds all line segments containing 4 or more points
    private final ArrayList<LineSegment> segs = new ArrayList<>();
    public FastCollinearPoints(Point[] points) {
        if (points == null)
            throw new IllegalArgumentException();
        for (Point point: points)
            if (point == null)
                throw new IllegalArgumentException();

        Point[] nps = new Point[points.length];
        for (int i = 0; i < points.length; i++)
            nps[i] = points[i];

        Arrays.sort(nps);
        for (int i = 1; i < nps.length; i++)
            if (nps[i - 1].compareTo(nps[i]) == 0)
                throw new IllegalArgumentException();

        // для каждой точки вычисляем наклон со всеми последующими
        // то, что получили запихиваем в массив и сортируем его.
        // далее идем по массиву и считаем одинаковые элементы (если находим 4 и более, то это наши точки)
        // проходимся по ним и отбираем мин и макс точку (хотя в общем из 2-х элементов достаточно) - это наш отрезок.
        // но надо избавиться от повторов точек (((
        for (int n = 0; n < nps.length - 1; n++) {
            Point p = nps[n];
            int i = n + 1;

            Arrays.sort(nps, i, nps.length, p.slopeOrder());
            while (i < nps.length - 1 &&
                    (p.slopeTo(nps[i]) != p.slopeTo(nps[i + 1]) ||
                    nps[i].equals(nps[i + 1])))
                i++;

            int k = i;
            while (k < nps.length && p.slopeTo(nps[i]) == p.slopeTo(nps[k])) {
                k++;
            }
            if (k - i >= 2) {
                int minIdx = n;
                int maxIdx = n;

                for (int j = i; j < k; j++) {
                    if (nps[minIdx].compareTo(nps[j]) > 0)
                        minIdx = j;
                    if (nps[maxIdx].compareTo(nps[j]) < 0)
                        maxIdx = j;
                }
                if (!nps[minIdx].equals(nps[maxIdx]))
                    segs.add(new LineSegment(nps[minIdx], nps[maxIdx]));
            }
            // удалить обработанные точки: нельзя, т.к. можем "выкусить" линию
            // n + [i, k]
            if (i != k)
                for (int j = i; j < k; j++)
                    nps[j] = p;
        }
    }

    private static <T> void copyArray(T[] source, T[] dest) {
        System.arraycopy(source, 0, dest, 0, source.length);
    }

    // the number of line segments
    public int numberOfSegments() {
        return segs.size();
    }

    // the line segments
    public LineSegment[] segments() {
        LineSegment[] res = new LineSegment[segs.size()];
        for (int i = 0; i < res.length; i++)
            res[i] = segs.get(i);
        return res;
    }

    public static void main(String[] args) {

        // read the n points from a file
        In in = new In(args.length > 0 ? args[0] : "inputOK.txt");
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(-10, 10);
        StdDraw.setYscale(-10, 10);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints_ collinear = new FastCollinearPoints_(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
