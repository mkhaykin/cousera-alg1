import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.StdDraw;

import java.util.ArrayList;

public class KdTree {
    private int size;
    // construct an empty set of points
    private Node root;

    private class Node {
        private Node left;
        private Node right;
        private final Point2D point;
        // private final int level;
        public Node(Point2D point) {
            if (point == null)
                throw new IllegalArgumentException();

            this.point = point;
        }
    }
    public KdTree() {
        size = 0;
        root = null;
    }

    // is the set empty?
    public boolean isEmpty() {
        return root == null;
    }

    // number of points in the set
    public int size() {
        return size;
    }

    // add the point to the set (if it is not already in the set)
    public void insert(Point2D p) {
        if (p == null)
            throw new IllegalArgumentException();

        if (root == null) {
            root = new Node(p);
            size = 1;
            return;
        }

        int level = 0;
        Node node = root;

        while (true) {
            if (node.point == p || p.equals(node.point))
                return;

            if ((level % 2 == 0 && p.x() < node.point.x()) ||
                    (level % 2 != 0 && p.y() < node.point.y())) {
                if (node.left == null) {
                    node.left = new Node(p);
                    break;
                }
                node = node.left;
            } else {
                if (node.right == null) {
                    node.right = new Node(p);
                    break;
                }
                node = node.right;
            }
            level++;
        }
        size++;
    }

    // does the set contain point p?
    public boolean contains(Point2D p)  {
        if (p == null)
            throw new IllegalArgumentException();


        int level = 0;
        Node node = root;
        while (node != null) {
            if (p.equals(node.point))
                return true;

            if ((level % 2 == 0 && p.x() < node.point.x()) ||
                    (level % 2 != 0 && p.y() < node.point.y()))
                node = node.left;
            else
                node = node.right;
            level++;
        }
        return false;
    }

    // draw all points to standard draw
    public void draw() {
        drawNode(root, 0, "");
    }

    private void drawNode(Node node, int level, String mark) {
        if (node == null)
            return;
        StdDraw.setPenRadius(0.01);
        StdDraw.point(node.point.x(), node.point.y());
        StdDraw.text(node.point.x(), node.point.y() + 0.025, Integer.toString(level) + mark);
        StdDraw.setPenRadius(0.001);
        if (level % 2 == 0)
            StdDraw.line(node.point.x(), 0, node.point.x(), 1);
        else
            StdDraw.line(0, node.point.y(), 1, node.point.y());
        level++;
        drawNode(node.left, level, "L");
        drawNode(node.right, level, "R");
    }

    // all points that are inside the rectangle (or on the boundary)
    public Iterable<Point2D> range(RectHV rect) {
        if (rect == null)
            throw new IllegalArgumentException();

        ArrayList<Point2D> list = new ArrayList<>();

        if (!isEmpty())
            range(rect, root, 0, list);

        return list;
    }

    private void range(RectHV rect, Node node, int level, ArrayList<Point2D> list) {
        if (node == null)
            return;

        Point2D point = node.point;

        if (rect.contains(point))
            list.add(point);
        if (level % 2 == 0) {
            // compare X
            if (node.left != null && point.x() >= rect.xmin())
                range(rect, node.left, level + 1, list);
            if (node.right != null && point.x() <= rect.xmax())
                range(rect, node.right, level + 1, list);
        } else {
            // compare Y
            if (node.left != null && point.y() >= rect.ymin()) {
                range(rect, node.left, level + 1, list);
            }
            if (node.right != null && point.y() <= rect.ymax()) {
                range(rect, node.right, level + 1, list);
            }
        }
    }

    // a nearest neighbor in the set to point p; null if the set is empty
    public Point2D nearest(Point2D p) {
        if (p == null)
            throw new IllegalArgumentException();

        if (isEmpty())
            return null;

        return nearest(p, root, root.point, p.distanceSquaredTo(root.point));
    }

    private Point2D nearest(Point2D p, Node node, Point2D minPoint, double minDist) {
        if (node == null)
            return minPoint;

        // bruteforce
        Point2D newMinPoint = minPoint;
        double dist;
        dist = p.distanceSquaredTo(node.point);
        if (dist < minDist) {
            newMinPoint = node.point;
            minDist = dist;
        }
        Point2D leftMinPoint = nearest(p, node.left, newMinPoint, minDist);
        Point2D rightMinPoint = nearest(p, node.right, newMinPoint, minDist);

        dist = p.distanceSquaredTo(leftMinPoint);
        if (dist < minDist) {
            newMinPoint = leftMinPoint;
            minDist = dist;
        }

        dist = p.distanceSquaredTo(rightMinPoint);
        if (dist < minDist) {
            newMinPoint = rightMinPoint;
            // minDist = dist;
        }

        return newMinPoint;
    }

    // unit testing of the methods (optional)
    public static void main(String[] args) {
//        KdTree kt = new KdTree();
//        kt.insert(new Point2D(0.7, 0.2));
//        System.out.println(kt.size());
//        System.out.println(kt.isEmpty());
//        kt.insert(new Point2D(0.5, 0.4));
//        System.out.println(kt.size());
//        System.out.println(kt.isEmpty());
//        kt.insert(new Point2D(0.2, 0.3));
//        kt.insert(new Point2D(0.4, 0.7));
//        kt.insert(new Point2D(0.9, 0.6));
//
//        System.out.println(kt.contains(new Point2D(0.9, 0.6)));
//        System.out.println(kt.contains(new Point2D(0.1, 0.1)));
//
//        System.out.println("OK");
//
//        for (Point2D point: kt.range(new RectHV(0.0, 0.39, 0.13, 0.93)))
//            System.out.println(point.toString());

        KdTree kt = new KdTree();
//        A  0.75 0.15625
//        B  0.84375 0.90625
//        C  0.9375 0.40625
//        D  0.03125 0.84375
//        E  0.875 0.75
//        F  0.40625 0.21875
//        G  0.28125 0.0
//        H  0.3125 0.3125
//        I  0.46875 0.71875
//        J  0.59375 0.03125
//        K  1.0 0.9375
//        L  0.625 1.0
//        M  0.34375 0.65625
//        N  0.0 0.59375
//        O  0.96875 0.1875
//        P  0.8125 0.875
//        Q  0.09375 0.53125
//        R  0.21875 0.34375
//        S  0.1875 0.375
//        T  0.375 0.46875
        kt.insert(new Point2D(0.75, 0.15625));
        kt.insert(new Point2D(0.84375, 0.90625));
        kt.insert(new Point2D(0.9375, 0.40625));
        kt.insert(new Point2D(0.03125, 0.84375));
        kt.insert(new Point2D(0.875, 0.75));
        kt.insert(new Point2D(0.40625, 0.21875));
        kt.insert(new Point2D(0.28125, 0.));
        kt.insert(new Point2D(0.3125, 0.3125));
        kt.insert(new Point2D(0.46875, 0.71875));
//        kt.insert(new Point2D(0., 0.));

        // RectHV rect = new RectHV(0.0625, 0.4375, 0.15625, 0.5625);
        RectHV rect = new RectHV(0.15625, 0.0625,0.4375,  0.5625);

        System.out.println("Point in rect " + rect.toString());
        for (Point2D point: kt.range(rect))
            System.out.println(point.toString());
        System.out.println("------------");

        Point2D point = new Point2D(0.45, 0.77);
        Point2D np = kt.nearest(point);
        System.out.println("nearest point: " + np.toString());
        System.out.println("------------");

        StdDraw.enableDoubleBuffering();
        StdDraw.clear();
        rect.draw();
        StdDraw.setPenColor(StdDraw.BLACK);
        kt.draw();
        StdDraw.setPenColor(StdDraw.RED);
        StdDraw.setPenRadius(0.01);
        point.draw();
        StdDraw.show();

//        RectHV rect = new RectHV(0.0, 0.0, 1.0, 1.0);
//        StdDraw.enableDoubleBuffering();
//
//        KdTree kdtree = new KdTree();
//        while (true) {
//            if (StdDraw.isMousePressed()) {
//                double x = StdDraw.mouseX();
//                double y = StdDraw.mouseY();
//                StdOut.printf("%8.6f %8.6f\n", x, y);
//                Point2D p = new Point2D(x, y);
//                if (rect.contains(p)) {
//                    StdOut.printf("%8.6f %8.6f\n", x, y);
//                    kdtree.insert(p);
//                    StdDraw.clear();
//                    kdtree.draw();
//                    StdDraw.show();
//                }
//            }
//            StdDraw.pause(20);
//        }
    }
}